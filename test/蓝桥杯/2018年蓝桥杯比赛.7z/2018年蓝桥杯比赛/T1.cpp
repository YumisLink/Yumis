#include<cstdio>
int main(int argc, char const *argv[])
{
    printf("%d",31+29+31+30+4);
    return 0;
}


//125

